function [lb,ub,D]=MyTestFunction_range(func_num)
if func_num==1
    lb=-100;ub=100;D=30;
end
if func_num==2
    lb=-5.12;ub=5.12;D=30;
end
if func_num==3
    lb=-30;ub=30;D=30;
end
if func_num==4
    lb=-10;ub=10;D=30;
end
if func_num==5
    lb=-1;ub=1;D=30;
end
if func_num==6
    lb=-10;ub=10;D=30;
end
if func_num==7
    lb=-10;ub=10;D=30;
end
if func_num==8
    lb=-5.12;ub=5.12;D=30;
end
if func_num==9
    lb=-1;ub=1;D=30;
end
if func_num==10
    lb=-100;ub=100;D=30;
end
if func_num==11
    lb=-65.536;ub=65.536;D=30;
end
if func_num==12
    lb=-5;ub=5;D=30;
end
if func_num==13
    lb=-4.5;ub=4.5;D=2;
end
if func_num==14
    lb=-10;ub=10;D=4;
end
if func_num==15
    lb=-500;ub=500;D=2;
end
if func_num==16
    lb=-500;ub=500;D=2;
end
if func_num==17
    lb=12;ub=60;D=4;
end
if func_num==18
    lb=-5;ub=5;D=2;
end
if func_num==19
    lb=-5;ub=5;D=2;
end
if func_num==20
    lb=-100;ub=100;D=2;
end
if func_num==21
    lb=-5;ub=5;D=2;
end
if func_num==22
    lb=-5.12;ub=5.12;D=30;
end
if func_num==23
    lb=-30;ub=30;D=30;
end
if func_num==24
    lb=-100;ub=100;D=30;
end
if func_num==25
    lb=-100;ub=100;D=30;
end
if func_num==26
    lb=-10;ub=10;D=30;
end
if func_num==27
    lb=-100;ub=100;D=30;
end
if func_num==28
    lb=-100;ub=100;D=30;
end
if func_num==29
    lb=-30;ub=30;D=30;
end
if func_num==30
    lb=-100;ub=100;D=30;
end
if func_num==31
    lb=-1.28;ub=1.28;D=30;
end
if func_num==32
    lb=-500;ub=500;D=30;
end
if func_num==33
    lb=-5.12;ub=5.12;D=30;
end
if func_num==34
    lb=-32;ub=32;D=30;
end
if func_num==35
    lb=-600;ub=600;D=30;
end
if func_num==36
    lb=-50;ub=50;D=30;
end
if func_num==37
    lb=-50;ub=50;D=30;
end
if func_num==38
    lb=0.01;
        ub=100;
        D=5;
end
end